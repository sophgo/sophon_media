export PATH=$PATH:/opt/sophon/sophon-gstreamer-latest/bin
export PKG_CONFIG_PATH=/opt/sophon/sophon-gstreamer-latest/lib/pkgconfig:$PKG_CONFIG_PATH
export GST_PLUGIN_PATH=/opt/sophon/sophon-gstreamer-latest/lib:$GST_PLUGIN_PATH