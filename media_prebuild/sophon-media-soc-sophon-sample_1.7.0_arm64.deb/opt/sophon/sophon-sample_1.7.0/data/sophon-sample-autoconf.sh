export PATH=$PATH:/opt/sophon/sophon-sample-latest/bin
